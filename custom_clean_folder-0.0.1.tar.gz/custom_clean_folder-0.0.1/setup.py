from setuptools import setup

setup(name='custom_clean_folder',
	version='0.0.1',
	  description='custom_clean_folder App',
	  url='https://github.com/domainplus',
author='domainplus',
author_email='luwable@gmail.com',
license='MIT',
packages=['custom_clean_folder'],
entry_points={'console_scripts': ['clean-folder = custom_clean_folder:clean']}
)

