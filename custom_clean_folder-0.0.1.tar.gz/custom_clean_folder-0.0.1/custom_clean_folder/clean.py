import sys

from custom_clean_folder import main_code

print(main_code.sort_content(sys.argv[1]))
main_code.delete_empty_folders(sys.argv[1])


