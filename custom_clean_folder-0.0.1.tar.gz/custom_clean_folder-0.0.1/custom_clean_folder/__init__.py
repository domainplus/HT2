
print('package custom_clean_folder imported successfuly')